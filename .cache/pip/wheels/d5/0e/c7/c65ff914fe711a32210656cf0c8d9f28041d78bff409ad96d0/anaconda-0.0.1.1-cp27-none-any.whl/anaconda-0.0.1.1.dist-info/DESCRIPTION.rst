Anaconda Python cannot be installed via pip or other PyPI-based installers.
Please use the Anaconda Installer to bootstrap Anaconda Python onto your system.


